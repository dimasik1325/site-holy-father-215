import { useLayoutEffect, useRef } from "react";
import siteHtml from "./site.html?raw";

/**
 * Весь сайт живёт в одном HTML-файле (src/site.html):
 * инлайновые <style> + инлайновый <script> + разметка.
 * Здесь мы лишь переносим этот документ в страницу:
 *  - <style> переносим в <head> (стили из innerHTML применяются, но так надёжнее);
 *  - <script> из innerHTML не исполняются — пересоздаём их, чтобы JS ожил.
 */
let injected = false;

function injectSite(root: HTMLElement) {
  if (injected) return;
  injected = true;

  const styleBlocks = siteHtml.match(/<style[^>]*>[\s\S]*?<\/style>/gi) || [];
  for (const block of styleBlocks) {
    const inner = block.match(/<style[^>]*>([\s\S]*?)<\/style>/i);
    if (!inner) continue;
    const style = document.createElement("style");
    style.textContent = inner[1];
    document.head.appendChild(style);
  }

  const bodyMatch = siteHtml.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
  root.innerHTML = bodyMatch ? bodyMatch[1] : siteHtml;

  const scripts = Array.from(root.querySelectorAll("script"));
  for (const old of scripts) {
    const fresh = document.createElement("script");
    fresh.textContent = old.textContent;
    document.body.appendChild(fresh);
  }
}

export default function App() {
  const ref = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    if (ref.current) injectSite(ref.current);
  }, []);

  return <div ref={ref} />;
}
